<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Maincontroller;
//use App\Http\Controllers\Auth\AuthController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


//Route::view('/', 'welcome'::class);

//Route::get('/', 'stockcontroller@index');
Route::get('/', [Maincontroller::class, 'index']);
Route::get('/numarray', [Maincontroller::class, 'numarrayfn']);
Route::get('/piglang', [Maincontroller::class, 'piglangfn']);
Route::get('/arrrotation', [Maincontroller::class, 'rotation']);
Route::post('number-digit', [Maincontroller::class, 'convert']);
Route::post('text-piglatin', [Maincontroller::class, 'translate']);

