<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Maincontroller extends Controller
{
    public function index()
    {
        return view('form');
    }

    public function numarrayfn()
    {
        return view('form1');
    }

    public function piglangfn()
    {
        return view('form2');
    }

    public function convert(Request $request)
    {
      $number = $request->numberval;
      $array  = array_map('intval', str_split($number));
      print_r($array);
    }

    public function translate(Request $request)
    {
      $text = $request->textval;
      $split = preg_split("/[^\w]*([\s]+[^\w]*|$)/", $text, -1, PREG_SPLIT_NO_EMPTY);
      $acronym = $output = "";
      foreach ($split as $w) {
        $acronym = mb_substr($w, 0, 1);
        $str = preg_replace('/^./', '', $w);
        $output .= ' '.$str.$acronym.'ay';
      }
    echo $output;
    }

  public function rotation(Request $request)
  {
    $arr = array(1, 2, 3, 4, 5); 
    $n = 3;
    print("Array befor rotation: <br>");
    print_r($arr);
    for ($i = 0; $i < $n; $i++){  
     
    $first = $arr[0];  
      
    for($j = 0; $j < count($arr)-1; $j++){  
         
        $arr[$j] = $arr[$j+1];  
    }  
    $arr[$j] = $first;  
  }  
  print("<br> Array after rotation: <br>");  
  print_r($arr); 
  }
}

