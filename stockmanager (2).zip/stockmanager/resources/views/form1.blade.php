<!DOCTYPE html>
<html>
<head>
    <title>Number to Array of Digits</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
  <div class="container mt-4">
 
  <div class="card">
    <div class="card-header text-center font-weight-bold">
      Laravel 8 - Add Blog Post Form Example
    </div>
    <div class="card-body">
      <form name="form1" id="form1" method="post" action="{{url('number-digit')}}">
       @csrf
        <div class="form-group">
          <label for="exampleInputEmail1">Enter a Number</label>
          <input type="text" id="numberval" name="numberval" class="form-control" required="">
        </div>
       
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </div>
</div>  
</body>
</html>