<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
  <div class="container mt-4">
 
  <div class="card">
    <div class="card-header text-center font-weight-bold">
     
    </div>
    <div class="card-body">
     
    <a href="/numarray">Number to Array of Digits  </a><br>
    <a href="/piglang"> English - Pig Latin</a><br>
    <a href="/arrrotation">Array Rotation </a><br>
    </div>
  </div>
</div>  
</body>
</html>