<!DOCTYPE html>
<html>
<head>
    <title>Conversion to Pig Latin</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
  <div class="container mt-4">
 
  <div class="card">
    <div class="card-header text-center font-weight-bold">
      English - Pig Latin
    </div>
    <div class="card-body">
      <form name="form2" id="form2" method="post" action="{{url('text-piglatin')}}">
       @csrf
        <div class="form-group">
          <label for="exampleInputEmail1">Enter a Text</label>
          <input type="text" id="textval" name="textval" class="form-control" required="">
        </div>
       
        <input type="hidden" id="langhid" name="langhid" value='0'>
        <button type="submit" id="eng-lat" class="btn btn-primary" onclick="myFunction('0')">Submit</button>
        <button type="submit" id="lat-eng" style="display: none" class="btn btn-primary" onclick="myFunction('1')">Submit</button>
      </form>
    </div>
  </div>
</div>  
</body>
</html>
<script type="text/javascript">
    function myFunction(translateval) {
        document.getElementById("demo").style.display = "red";
    }   
</script>  